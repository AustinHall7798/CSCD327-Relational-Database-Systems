/*****************************
Query the University Database
*****************************/
import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.Scanner;

public class MyQuery {

    private Connection conn = null;
	 private Statement statement = null;
	 private ResultSet resultSet = null;
    
    public MyQuery(Connection c)throws SQLException
    {
        conn = c;
        // Statements allow to issue SQL queries to the database
        statement = conn.createStatement();
    }
    
    public void findFall2009Students() throws SQLException
    {
        String query  = "select distinct name from student natural join takes where semester = \'Fall\' and year = 2009;";

        resultSet = statement.executeQuery(query);
    }
    
    public void printFall2009Students() throws IOException, SQLException
    {
	      System.out.println("******** Query 0 ********");
         System.out.println("name");
         while (resultSet.next()) {
			// It is possible to get the columns via name
			// also possible to get the columns via the column number which starts at 1
			String name = resultSet.getString(1);
         System.out.println(name);
   		}        
    }

    public void findGPAInfo() throws SQLException
    {
    	String query = "	SELECT \n" + 
    			"    ID,\n" + 
    			"    name,\n" + 
    			"    ((SUM(CASE\n" + 
    			"        WHEN grade = 'A' THEN 4.0\n" + 
    			"        WHEN grade = 'A-' THEN 3.67\n" + 
    			"        WHEN grade = 'B+' THEN 3.33\n" + 
    			"        WHEN grade = 'B' THEN 3\n" + 
    			"        WHEN grade = 'B-' THEN 2.67\n" + 
    			"        WHEN grade = 'C+' THEN 2.33\n" + 
    			"        WHEN grade = 'C' THEN 2\n" + 
    			"        WHEN grade = 'C-' THEN 1.67\n" + 
    			"        WHEN grade = 'D+' THEN 1.33\n" + 
    			"        WHEN grade = 'D' THEN 1\n" + 
    			"        WHEN grade = 'D-' THEN 0.67\n" + 
    			"        WHEN grade = 'F' THEN 0\n" + 
    			"    END * credits)) / SUM(credits)) AS GPA\n" + 
    			"FROM\n" + 
    			"    takes\n" + 
    			"        JOIN\n" + 
    			"    student USING (ID)\n" + 
    			"        JOIN\n" + 
    			"    course USING (course_id)\n" + 
    			"WHERE\n" + 
    			"    grade IS NOT NULL\n" + 
    			"GROUP BY ID;";
    	resultSet = statement.executeQuery(query);
    	
    }

    public void printGPAInfo() throws IOException, SQLException {
    	 System.out.println("******** Query 1 ********");
		   System.out.printf("%-10s %1.7s %-10s %1.7s %s%n", "ID", "|",  "Name", "|", "GPA");
		   System.out.println("----------------------------------");
	         while (resultSet.next()) {
	         System.out.printf("%-10s %1.7s %-10s %1.7s %s%n", resultSet.getString(1), "|", resultSet.getString(2), "|", resultSet.getString(3));
	   		}
    }
    
    public void findMorningCourses() throws SQLException
    {

    	String query = 
    	"SELECT \n" + 
    	"    course_id,\n" + 
    	"    sec_id,\n" + 
    	"    title,\n" + 
    	"    semester,\n" + 
    	"    year,\n" + 
    	"    name,\n" + 
    	"    COUNT(DISTINCT SID) enrollment\n" + 
    	"FROM\n" + 
    	"    course\n" + 
    	"        JOIN\n" + 
    	"    section USING (course_ID)\n" + 
    	"        JOIN\n" + 
    	"    time_slot USING (time_slot_id)\n" + 
    	"        JOIN\n" + 
    	"    (SELECT \n" + 
    	"        ID SID, course_id, sec_id, semester, year\n" + 
    	"    FROM\n" + 
    	"        takes) t USING (course_ID , sec_id , semester , year)\n" + 
    	"        JOIN\n" + 
    	"    teaches USING (course_id , sec_id , semester , year)\n" + 
    	"        JOIN\n" + 
    	"    instructor USING (ID)\n" + 
    	"WHERE\n" + 
    	"    start_hr <= 12\n" + 
    	"GROUP BY course_id , sec_id , title , semester , year , name;";
    	resultSet = statement.executeQuery(query);
    }

    public void printMorningCourses() throws IOException, SQLException
    {
	   	System.out.println("******** Query 2 ********");
	    System.out.printf("%-10s %1.7s %-3s %1.7s %-30s %1.7s %-10s %1.7s %-10s %1.7s %-10s %1.7s %s%n", "Course_Id", "|",  "Sec_Id", "|", "Title", "|",  "Semester", "|", "Year", "|", "Name", "|", "Enrollment");
		   System.out.println("--------------------------------------------------------------------------------------------------------");
	         while (resultSet.next()) {
	         System.out.printf("%-10s %1.7s %-6s %1.7s %-30s %1.7s %-10s %1.7s %-10s %1.7s %-10s %1.7s %s%n", resultSet.getString(1), "|", resultSet.getString(2), "|", resultSet.getString(3), "|", resultSet.getString(4), "|", resultSet.getString(5), "|", resultSet.getString(6), "|", resultSet.getString(7));
	   		}
    }

    public void findBusyInstructor() throws SQLException
    {
 
    	String query = "SELECT \n" + 
    			"    name\n" + 
    			"FROM\n" + 
    			"    teaches\n" + 
    			"        NATURAL JOIN\n" + 
    			"    instructor\n" + 
    			"GROUP BY id\n" + 
    			"HAVING COUNT(id) = (SELECT \n" + 
    			"        MAX(idCount)\n" + 
    			"    FROM\n" + 
    			"        (SELECT \n" + 
    			"            COUNT(id) AS idCount\n" + 
    			"        FROM\n" + 
    			"            instructor\n" + 
    			"        NATURAL JOIN teaches\n" + 
    			"        GROUP BY ID) AS counted);";
    	resultSet = statement.executeQuery(query);
    }

    public void printBusyInstructor() throws IOException, SQLException
    {
		   System.out.println("******** Query 3 ********");
		   System.out.println("Name");
		   System.out.println("-----------");
	         while (resultSet.next()) {
	         System.out.println(resultSet.getString(1));
	   		}
    }

    public void findPrereq() throws SQLException
    {
    	String query = "SELECT \n" + 
    			"    title AS course,\n" + 
    			"    COALESCE((SELECT \n" + 
    			"                    title\n" + 
    			"                FROM\n" + 
    			"                    course\n" + 
    			"                WHERE\n" + 
    			"                    course_id = prereq_id), \"\") AS prereq\n" + 
    			"FROM\n" + 
    			"    course outter\n" + 
    			"        LEFT JOIN\n" + 
    			"    prereq USING (course_id);";
    	resultSet = statement.executeQuery(query);

    }

    public void printPrereq() throws IOException, SQLException
    {
		   System.out.println("******** Query 4 ********");
		   System.out.printf("%-30s %1.7s %s%n", "Course", "|",  "Prereq");
		   System.out.println("-------------------------------------------------------------");
	         while (resultSet.next()) {
	         System.out.printf("%-30s %1.7s %s%n", resultSet.getString(1), "|", resultSet.getString(2));
	   		}
    }

    public void updateTable() throws SQLException
    {
    	String query = "CREATE TABLE IF NOT EXISTS studentCopy SELECT * FROM\n" + 
    			"    student;";
    	
    			statement.executeUpdate(query);
    			
    			query = "UPDATE studentCopy \n" + 
    					"SET \n" + 
    					"    tot_cred = (SELECT \n" + 
    					"            COALESCE(SUM(credits), 0)\n" + 
    					"        FROM\n" + 
    					"            takes\n" + 
    					"                JOIN\n" + 
    					"            course USING (course_id)\n" + 
    					"        WHERE\n" + 
    					"            studentCopy.ID = takes.ID\n" + 
    					"                AND grade != 'F');";
    			
    		statement.executeUpdate(query);
    		query = "SELECT ID, name, dept_name, tot_cred FROM studentCopy";
    		resultSet = statement.executeQuery(query);

    }

    public void printUpdatedTable() throws IOException, SQLException
    {
		   System.out.println("******** Query 5 ********");
		   System.out.printf("%-10s %1.7s %-10s %1.7s %-10s %1.7s %s%n", "ID", "|",  "Name", "|", "Dept_Name", "|", "Tot_Cred");
		   System.out.println("-----------------------------------------------");
	         while (resultSet.next()) {
	         System.out.printf("%-10s %1.7s %-10s %1.7s %-10s %1.7s %s%n", resultSet.getString(1), "|", resultSet.getString(2), "|", resultSet.getString(3), "|", resultSet.getString(4));
	   		}
    }
	
	public void findHeadCounts() throws SQLException {
		Scanner scan = new Scanner(System.in);
		String departmentName;
		System.out.println("******** Query 6 ********");
		System.out.println("Please enter the department name:");
		departmentName = scan.nextLine();
		CallableStatement cs = conn.prepareCall("{call getNumbers(?,?,?)}");
		cs.registerOutParameter(2, Types.INTEGER);
		cs.registerOutParameter(3, Types.INTEGER);
		cs.setString(1, departmentName);
		cs.execute();
		System.out.println(departmentName + " department has " + cs.getInt(2) + " instructors.\n");
		System.out.println(departmentName + " department has " + cs.getInt(3) + " students.\n");
		scan.close();
	}
    
    
    // extra credit
    public void findFirstLastSemester() throws SQLException
    {
    	String query = "SELECT \n" + 
    			"    id, name, First_Semester, Last_Semester\n" + 
    			"FROM\n" + 
    			"    (SELECT DISTINCT\n" + 
    			"        id, name, CONCAT(semester, ' ', year) AS First_Semester\n" + 
    			"    FROM\n" + 
    			"        (SELECT \n" + 
    			"        ID,\n" + 
    			"            name,\n" + 
    			"            semester,\n" + 
    			"            year,\n" + 
    			"            CASE\n" + 
    			"                WHEN semester = 'Spring' THEN 1\n" + 
    			"                WHEN semester = 'Summer' THEN 2\n" + 
    			"                WHEN semester = 'Fall' THEN 3\n" + 
    			"            END AS num\n" + 
    			"    FROM\n" + 
    			"        student\n" + 
    			"    JOIN takes USING (id)) AS t\n" + 
    			"    WHERE\n" + 
    			"        year = (SELECT \n" + 
    			"                MIN(year)\n" + 
    			"            FROM\n" + 
    			"                takes t2\n" + 
    			"            WHERE\n" + 
    			"                t.id = t2.id)\n" + 
    			"            AND num = (SELECT \n" + 
    			"                MIN(num)\n" + 
    			"            FROM\n" + 
    			"                (SELECT \n" + 
    			"                id,\n" + 
    			"                    year,\n" + 
    			"                    CASE\n" + 
    			"                        WHEN semester = 'Spring' THEN 1\n" + 
    			"                        WHEN semester = 'Summer' THEN 2\n" + 
    			"                        WHEN semester = 'Fall' THEN 3\n" + 
    			"                    END AS num\n" + 
    			"            FROM\n" + 
    			"                takes) AS t4\n" + 
    			"            WHERE\n" + 
    			"                t.id = t4.id AND t4.year = t.year)) AS s1\n" + 
    			"        JOIN\n" + 
    			"    (SELECT DISTINCT\n" + 
    			"        id, name, CONCAT(semester, ' ', year) AS Last_Semester\n" + 
    			"    FROM\n" + 
    			"        (SELECT \n" + 
    			"        ID,\n" + 
    			"            name,\n" + 
    			"            semester,\n" + 
    			"            year,\n" + 
    			"            CASE\n" + 
    			"                WHEN semester = 'Spring' THEN 1\n" + 
    			"                WHEN semester = 'Summer' THEN 2\n" + 
    			"                WHEN semester = 'Fall' THEN 3\n" + 
    			"            END AS num\n" + 
    			"    FROM\n" + 
    			"        student\n" + 
    			"    JOIN takes USING (id)) AS t\n" + 
    			"    WHERE\n" + 
    			"        year = (SELECT \n" + 
    			"                MAX(year)\n" + 
    			"            FROM\n" + 
    			"                takes t2\n" + 
    			"            WHERE\n" + 
    			"                t.id = t2.id)\n" + 
    			"            AND num = (SELECT \n" + 
    			"                MAX(num)\n" + 
    			"            FROM\n" + 
    			"                (SELECT \n" + 
    			"                id,\n" + 
    			"                    year,\n" + 
    			"                    CASE\n" + 
    			"                        WHEN semester = 'Spring' THEN 1\n" + 
    			"                        WHEN semester = 'Summer' THEN 2\n" + 
    			"                        WHEN semester = 'Fall' THEN 3\n" + 
    			"                    END AS num\n" + 
    			"            FROM\n" + 
    			"                takes) AS t4\n" + 
    			"            WHERE\n" + 
    			"                t.id = t4.id AND t4.year = t.year)) AS s2 USING (id , name)\n" + 
    			"ORDER BY id;";
    	resultSet = statement.executeQuery(query);
 
    }

	public void printFirstLastSemester() throws IOException, SQLException {
		System.out.println("******** Query 7 ********");
		System.out.printf("%-10s %1.7s %-10s %1.7s %-10s %1.7s %s%n", "ID", "|", "Name", "|", "First_Semester", "|",
				"Last_Semester");
		System.out.println("--------------------------------------------------------");
		while (resultSet.next()) {
			System.out.printf("%-10s %1.7s %-10s %1.7s %-14s %1.7s %s%n", resultSet.getString(1), "|",
					resultSet.getString(2), "|", resultSet.getString(3), "|", resultSet.getString(4));
		}
	}

}
